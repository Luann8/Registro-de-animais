# djangoProject/urls.py
from django.contrib import admin
from django.urls import path, include
from home.views import home_view  # Certifique-se de importar a visão corretamente

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('rest_framework.urls')),
    path('', home_view, name='home'),  # Adiciona a URL raiz
]
