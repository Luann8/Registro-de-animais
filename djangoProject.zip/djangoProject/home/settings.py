INSTALLED_APPS = [
    # outras aplicações
    'home',
]

STATIC_URL = '/static/'