# animals/models.py
from django.db import models

class Animal(models.Model):
    animal_id = models.CharField(max_length=100)
    brinco_id = models.CharField(max_length=100)
    lote = models.CharField(max_length=100)
    manejo = models.CharField(max_length=100)
    nascimento = models.DateField()
    idade = models.IntegerField()
    raca = models.CharField(max_length=100)
    sexo = models.CharField(max_length=10)
    categoria = models.CharField(max_length=100)
    cria = models.CharField(max_length=100, blank=True, null=True)
    mae = models.CharField(max_length=100)
    pai = models.CharField(max_length=100)
    peso_anterior = models.DecimalField(max_digits=10, decimal_places=2)
    peso_anterior_data = models.DateField()
    medicamentos = models.TextField(blank=True, null=True)
    obs = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.animal_id
